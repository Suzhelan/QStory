package HookItem.LoadItemInfo;

//实现按名称查找方法的功能类 可以查找混淆类名但不混淆方法名的方法
public class FindBaseMethodByName extends BaseFindBaseMethodInfo {
    public String name;
}
