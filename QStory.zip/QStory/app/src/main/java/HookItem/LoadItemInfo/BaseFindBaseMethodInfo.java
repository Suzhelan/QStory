package HookItem.LoadItemInfo;

public class BaseFindBaseMethodInfo extends BaseMethodInfo {
    public String LinkedToMethodID;

    public BaseMethodInfo.MethodChecker checker;

    public Class<?> InClass;
    public int paramCount;
    public BaseMethodInfo[] paramTypes;
    public BaseMethodInfo returnType;


}
