package HookItem.LoadItemInfo;

import java.lang.reflect.Member;

public class FindMethodInvokingMethod extends BaseFindMethodInfo {
    public Member checkMethod;
}
