package HookItem.LoadItemInfo;

import java.lang.reflect.Member;

//常用方法--即使版本更新也不会混淆的方法
public class CommonBaseMethodInfo extends BaseMethodInfo {
    public Member member;
}
