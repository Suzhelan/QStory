package HookItem.LoadItemInfo;

import java.lang.reflect.Member;

public class FindMethodsWhichInvokeToTargetMethod extends BaseFindMethodInfo {
    public Member checkMethod;
}
