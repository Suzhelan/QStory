package HookItem.ChatHook.EomManager;

import android.view.View;

public class EmoJiTools {
    public static void deleteEmo(Emo emo) {

    }

    //添加一个图片
    public static void addEmoView(View view, Emo emo) {

    }

    public static class Emo {
        public String path;
        public String MD5;
    }
}
