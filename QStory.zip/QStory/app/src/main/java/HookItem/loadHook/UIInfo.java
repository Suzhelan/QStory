package HookItem.loadHook;

import android.view.View;

public class UIInfo {
    public static final int PERIOD = 1;
    public String name, info, groupType;//UI
    public String id;
    public int period = PERIOD;
    public View.OnClickListener onClick;
}
