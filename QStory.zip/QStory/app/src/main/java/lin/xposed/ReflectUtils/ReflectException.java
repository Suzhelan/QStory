package lin.xposed.ReflectUtils;

public class ReflectException extends Exception {

}
