package lin.xposed.LayoutView.ItemInfo;

public class ClassifyMenu {
    public final static String[] mainClassify = {"功能", "净化","实验功能","调试方面", "关于与更新"};
    public final static String base = mainClassify[0];
    public final static String streamline = mainClassify[1];

}
