package ConfigTool;

import java.lang.reflect.Method;

public class DexFindTool {
    public static Method[] findMethodByString(String str) {
        return null;
    }
    public static Method[] findMethodBeInvoked(Method beInvoked) {
        return null;
    }
    public static Method[] findMethodInvoking(Method beInvoked) {
        return null;
    }
}
