public class RootData {
    public static String 春风浴美人 = "尽显盛世容颜";
}
